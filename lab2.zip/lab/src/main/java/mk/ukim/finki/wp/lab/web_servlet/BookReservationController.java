package mk.ukim.finki.wp.lab.web_servlet;


import mk.ukim.finki.wp.lab.service.IBookReservationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookReservationController {
    private final IBookReservationService reservationService;

    public BookReservationController(IBookReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping("/bookReservation")
    public String place(@RequestParam String bookTitle,
                        @RequestParam String readerName,
                        @RequestParam String readerAddress,
                        @RequestParam Integer numCopies,
                        Model model) {



        reservationService.placeReservation(bookTitle, readerName, readerAddress, numCopies);

        model.addAttribute("readerName", readerName);
        model.addAttribute("bookTitle", bookTitle);
        model.addAttribute("numCopies", numCopies);
        return "reservationConfirmation";
    }
}
