package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.IBookRepository;
import mk.ukim.finki.wp.lab.service.IAuthorService;
import mk.ukim.finki.wp.lab.service.IBookService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements IBookService {
    private final IBookRepository bookRepository;
    private final IAuthorService authorService;

    public BookServiceImpl(IBookRepository bookRepository, IAuthorService authorService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
    }

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }

    @Override
    public List<Book> searchBooks(String text, Double rating) {
        return bookRepository.searchBooks(text, rating);
    }

    @Override
    public void delete(Long id) {
        bookRepository.delete(id);
    }

    @Override
    public Book save(String title, String genre, Double averageRating, Long authorId) {
        Long id = 111L;
        Book book = new Book(id,title, genre, averageRating, authorService.findById(authorId).get());
        id = id + 1;
        return bookRepository.save(book);
    }

    @Override
    public Optional<Book> findbyId(Long id) {
        return bookRepository.findbyId(id);
    }

}
