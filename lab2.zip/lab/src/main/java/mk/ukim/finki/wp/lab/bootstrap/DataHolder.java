package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import jdk.jfr.Category;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Book> books = null;
    public static List<BookReservation> reservations = null;
    public static List<Author> authors = null;

    @PostConstruct
    public void init() {
        books = new ArrayList<>();
        reservations = new ArrayList<>();
        authors = new ArrayList<>();

        Author GeorgeOrwell = new Author(1L, "George", "Orwell", "United Kingdom", "Orwell's biography");
        Author RayBradbury = new Author(2L, "Ray", "Bradbury", "USA", "Ray's biography");
        Author AldousHuxley = new Author(3L, "Aldous", "Huxley", "United Kingdom", "Aldous's biography");
        Author FyodorDostoevsky = new Author(4L, "Fyodor", "Dostoevsky", "Russian Empire", "Fyodor's biography");
        Author IanFleming = new Author(5L, "Ian", "Fleming", "English", "Ian's biography");
        Author PetreAndreevski = new Author(6L, "Petre", "Andreevski", "Macedonian", "Petre's biography");
        Author MrdnatCovek = new Author(7L, "Mrdnat", "Covek", "Torko", "MrdnatCovek's biography");

        authors.add(GeorgeOrwell);
        authors.add(RayBradbury);
        authors.add(AldousHuxley);
        authors.add(FyodorDostoevsky);
        authors.add(IanFleming);
        authors.add(PetreAndreevski);
        authors.add(MrdnatCovek);

        books.add(new Book(101L, "1984", "Dystopia", 10.0, GeorgeOrwell));
        books.add(new Book(102L, "Brave New World", "Dystopia", 8.0, AldousHuxley));
        books.add(new Book(103L, "Fahrenheit 451", "Dystopia", 8.2, RayBradbury));
        books.add(new Book(104L, "Brothers Karamazov", "Novel", 10.0, FyodorDostoevsky));
        books.add(new Book(105L, "Casino Royale", "Fiction", 9.0, IanFleming));
        books.add(new Book(106L, "Live and Let Die", "Fiction", 9.3, IanFleming));
        books.add(new Book(107L, "Poslednite Selani", "Fiction", 9.5, PetreAndreevski));
        books.add(new Book(108L, "Pirej", "Novel", 10.0, PetreAndreevski));
        books.add(new Book(109L, "Hemija za 8mo Odd", "Torture", 1.0, MrdnatCovek));
        books.add(new Book(110L, "Hemija za 1va Sredno", "Torture", 1.0, MrdnatCovek));
    }
}
