package mk.ukim.finki.wp.lab.bootstrap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails admin = User.builder()
                .username("admin")
                .password("{noop}admin")
                .roles("ADMIN")
                .build();

        return new InMemoryUserDetailsManager(admin);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http.csrf(csrf -> csrf.disable());

        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/h2-console/**").permitAll()
                // public pages (not logged in can see)
                .requestMatchers("/", "/books", "/login", "/css/**", "/js/**", "/images/**").permitAll()

                // ONLY ADMIN can open add/edit pages (GET)
                .requestMatchers("/books/book-form", "/books/book-form/**").hasRole("ADMIN")

                // ONLY ADMIN can mutate (POST)
                .requestMatchers(HttpMethod.POST, "/books/add", "/books/edit/**", "/books/delete/**").hasRole("ADMIN")

                // spec says: everything else visible without login
                .anyRequest().permitAll()
        );

        http.formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login") // Spring Security handles POST /login here
                .defaultSuccessUrl("/books", true)
                .failureUrl("/login?error=true")
                .permitAll()
        );

        http.logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/books")
        );

        return http.build();
    }
}
