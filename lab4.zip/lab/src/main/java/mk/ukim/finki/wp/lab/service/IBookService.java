package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Book;

import java.util.List;
import java.util.Optional;

public interface IBookService {
    List<Book> listAll();
    //List<Book> searchBooks(String text, Double rating);

    void delete(Long id);
    Book save(String title, String genre, Double averageRating, Long authorId);

    Optional<Book> findbyId(Long id);
}
