package mk.ukim.finki.wp.lab.web_servlet;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import org.springframework.ui.Model;
import mk.ukim.finki.wp.lab.repository.IAuthorRepository;
import mk.ukim.finki.wp.lab.service.IAuthorService;
import mk.ukim.finki.wp.lab.service.IBookReservationService;
import mk.ukim.finki.wp.lab.service.IBookService;
import mk.ukim.finki.wp.lab.service.impl.BookServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/books")
public class BookController {

    private final IBookService bookService;
    private final IAuthorService authorService;

    public BookController(IBookService bookService, IAuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    // 4.1 list /books -> listBooks.html
    @GetMapping
    public String getBooksPage(@RequestParam(required = false) String error, Model model) {
        if (error != null) model.addAttribute("error", error);
        model.addAttribute("books", bookService.listAll());
        model.addAttribute("authors", authorService.findAll());
        return "listBooks";
    }

    // 7. GET form for ADD  -> /books/book-form
    @GetMapping("/book-form")
    public String getAddBookPage(Model model) {
        model.addAttribute("mode", "add");
        model.addAttribute("authors", authorService.findAll());
        // no book attribute when adding
        return "book-form";
    }

    // 7. GET form for EDIT -> /books/book-form/{id}
    @GetMapping("/book-form/{id}")
    public String getEditBookForm(@PathVariable Long id, Model model) {
        var opt = bookService.findbyId(id);
        if (opt.isEmpty()) {
            return "redirect:/books?error=BookNotFound";
        }
        model.addAttribute("mode", "edit");
        model.addAttribute("book", opt.get());
        model.addAttribute("authors", authorService.findAll());
        return "book-form";
    }

    // 4.2 CREATE -> POST /books/add
    @PostMapping("/add")
    public String saveBook(@RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {
        bookService.save(title, genre, averageRating, authorId);
        return "redirect:/books";
    }

    // 4.3 UPDATE -> POST /books/edit/{bookId}
    @PostMapping("/edit/{bookId}")
    public String editBook(@PathVariable Long bookId,
                           @RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId) {
        // either call a dedicated update or reuse save(bookId,...)
        bookService.save(title, genre, averageRating, authorId);
        return "redirect:/books";
    }

    // 4.4 DELETE -> POST /books/delete/{id}
    @PostMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        bookService.delete(id);
        return "redirect:/books";
    }
}

