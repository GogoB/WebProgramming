package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.IAuthorRepository;
import mk.ukim.finki.wp.lab.repository.IAuthorRepository;
import mk.ukim.finki.wp.lab.repository.IBookRepository;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("h2")
public class H2DataBootstrap {

    private final IAuthorRepository authorRepository;
    private final IBookRepository bookRepository;

    public H2DataBootstrap(IAuthorRepository authorRepository,
                           IBookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @PostConstruct
    public void init() {


        if (authorRepository.count() > 0 || bookRepository.count() > 0) {
            return;
        }

        Author GeorgeOrwell = new Author(1L, "George", "Orwell", "United Kingdom", "Orwell's biography");
        Author RayBradbury = new Author(2L, "Ray", "Bradbury", "USA", "Ray's biography");
        Author AldousHuxley = new Author(3L, "Aldous", "Huxley", "United Kingdom", "Aldous's biography");
        Author FyodorDostoevsky = new Author(4L, "Fyodor", "Dostoevsky", "Russian Empire", "Fyodor's biography");
        Author IanFleming = new Author(5L, "Ian", "Fleming", "English", "Ian's biography");
        Author PetreAndreevski = new Author(6L, "Petre", "Andreevski", "Macedonian", "Petre's biography");
        Author MrdnatCovek = new Author(7L, "Mrdnat", "Covek", "Torko", "MrdnatCovek's biography");

        authorRepository.save(GeorgeOrwell);
        authorRepository.save(RayBradbury);
        authorRepository.save(AldousHuxley);
        authorRepository.save(FyodorDostoevsky);
        authorRepository.save(IanFleming);
        authorRepository.save(PetreAndreevski);
        authorRepository.save(MrdnatCovek);

        bookRepository.save(new Book(101L, "1984", "Dystopia", 10.0, GeorgeOrwell));
        bookRepository.save(new Book(102L, "Brave New World", "Dystopia", 8.0, AldousHuxley));
        bookRepository.save(new Book(103L, "Fahrenheit 451", "Dystopia", 8.2, RayBradbury));
        bookRepository.save(new Book(104L, "Brothers Karamazov", "Novel", 10.0, FyodorDostoevsky));
        bookRepository.save(new Book(105L, "Casino Royale", "Fiction", 9.0, IanFleming));
        bookRepository.save(new Book(106L, "Live and Let Die", "Fiction", 9.3, IanFleming));
        bookRepository.save(new Book(107L, "Poslednite Selani", "Fiction", 9.5, PetreAndreevski));
        bookRepository.save(new Book(108L, "Pirej", "Novel", 10.0, PetreAndreevski));
        bookRepository.save(new Book(109L, "Hemija za 8mo Odd", "Torture", 1.0, MrdnatCovek));
        bookRepository.save(new Book(110L, "Hemija za 1va Sredno", "Torture", 1.0, MrdnatCovek));
    }
}
