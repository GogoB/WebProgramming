package mk.ukim.finki.wp.lab.exceptions;

public class EmptyListException extends Exception{
}
